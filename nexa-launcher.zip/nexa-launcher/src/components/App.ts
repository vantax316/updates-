export function renderApp(): string {
  return `
    <div class="titlebar" data-tauri-drag-region>
      <span class="titlebar-title">Nexa</span>
      <div class="titlebar-controls">
        <button class="ctrl-btn ctrl-min" id="btn-minimize" title="Minimize">&#8212;</button>
        <button class="ctrl-btn ctrl-close" id="btn-close" title="Close">&#215;</button>
      </div>
    </div>

    <div class="app-body">
      <canvas id="stars-canvas" class="stars-canvas"></canvas>

      <aside class="sidebar">
        <nav class="nav-icons">
          <!-- Home -->
          <button class="nav-btn active" data-tab="home" title="Home" tabindex="-1">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
          </button>
          <!-- Library — exact Lucide Library icon: 4 vertical lines (book spines) -->
          <button class="nav-btn" data-tab="library" title="Library" tabindex="-1">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
              <path d="m16 6 4 14"/>
              <path d="M12 6v14"/>
              <path d="M8 8v12"/>
              <path d="M4 4v16"/>
            </svg>
          </button>
        </nav>
      </aside>

      <main class="main-content">

        <!-- HOME TAB -->
        <div class="tab-content active" id="tab-home">
          <div class="home-inner">

            <!-- Greeting card — full width, skin as tall as card like launcher-fixed ref -->
            <div class="greeting-card">
              <img class="skin-img" src="/default-skin.png" alt="skin" />
              <div class="greeting-text">
                <span class="greeting-sub">Welcome,</span>
                <span class="greeting-name">Player</span>
              </div>
            </div>

            <!-- Banner -->
            <div class="hero-banner">
              <div class="hero-bg"></div>
              <div class="hero-overlay"></div>
              <div class="hero-info">
                <h2 class="banner-title">CHAPTER 2, SEASON 2</h2>
                <p class="hero-desc">The Agency took control as shadowy organizations battled for the island. Players chose a side — Ghost or Shadow — in a global spy conflict. New bosses, mythic weapons, and henchmen changed the game as Chapter 2 Season 2 brought the biggest operation yet.</p>
              </div>
            </div>

            <!-- Support card -->
            <div class="support-card">
              <div class="support-bg"></div>
              <div class="support-overlay"></div>
              <div class="support-text">
                <h3 class="support-title">Support Us!</h3>
                <p class="support-desc">Help keep our servers running and support ongoing development. Every contribution makes a difference!</p>
                <button class="donate-btn">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                  Donate Now
                </button>
              </div>
            </div>

          </div>
        </div>

        <!-- LIBRARY TAB -->
        <div class="tab-content" id="tab-library">
          <div class="library-inner">
            <div class="library-header">
              <h1 class="library-title">Library</h1>
              <p class="library-sub">View, manage, and launch all your builds all in one place.</p>
            </div>
            <div class="empty-state">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="44" height="44">
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
              </svg>
              <p>No builds yet</p>
            </div>
          </div>
        </div>

      </main>
    </div>
  `;
}
