export function initBanner(): void {
  // ── Starfield ──────────────────────────────────────────
  const canvas = document.getElementById("stars-canvas") as HTMLCanvasElement;
  if (!canvas) return;

  const ctx = canvas.getContext("2d")!;

  interface Star {
    x: number; y: number;
    r: number; speed: number; opacity: number;
  }

  let stars: Star[] = [];
  let animFrame: number;

  function resize() {
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }

  function makeStars(count: number) {
    stars = [];
    for (let i = 0; i < count; i++) {
      stars.push({
        x:       Math.random() * canvas.width,
        y:       Math.random() * canvas.height,
        r:       Math.random() * 1.2 + 0.2,
        speed:   Math.random() * 0.3 + 0.05,
        opacity: Math.random() * 0.7 + 0.2,
      });
    }
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const s of stars) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(200,210,255,${s.opacity})`;
      ctx.fill();

      // Slow drift downward — subtle twinkling parallax
      s.y += s.speed;
      if (s.y > canvas.height + 2) {
        s.y = -2;
        s.x = Math.random() * canvas.width;
      }

      // Twinkle
      s.opacity += (Math.random() - 0.5) * 0.02;
      s.opacity = Math.max(0.1, Math.min(0.9, s.opacity));
    }
    animFrame = requestAnimationFrame(draw);
  }

  resize();
  makeStars(220);
  draw();

  window.addEventListener("resize", () => {
    cancelAnimationFrame(animFrame);
    resize();
    makeStars(220);
    draw();
  });

  // ── Play button (if ever re-added) ────────────────────
  const playBtn = document.querySelector<HTMLButtonElement>(".play-btn");
  playBtn?.addEventListener("click", () => console.log("Launch..."));
}
