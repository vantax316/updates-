import { appWindow } from "@tauri-apps/api/window";

export function initNavigation(): void {
  const navBtns = document.querySelectorAll<HTMLButtonElement>(".nav-btn");
  const tabs     = document.querySelectorAll<HTMLDivElement>(".tab-content");

  // Immediately blur every button after mousedown so focus ring never shows
  document.querySelectorAll<HTMLButtonElement>("button").forEach(btn => {
    btn.addEventListener("mousedown", (e) => {
      e.preventDefault(); // prevents focus entirely
    });
  });

  navBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      navBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      tabs.forEach(t => t.classList.remove("active"));
      document.getElementById(`tab-${btn.dataset.tab}`)?.classList.add("active");
    });
  });

  document.getElementById("btn-minimize")?.addEventListener("click", () => void appWindow.minimize());
  document.getElementById("btn-maximize")?.addEventListener("click", async () => {
    (await appWindow.isMaximized()) ? void appWindow.unmaximize() : void appWindow.maximize();
  });
  document.getElementById("btn-close")?.addEventListener("click", () => void appWindow.close());
}
