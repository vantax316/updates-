import "./style.css";
import { renderApp } from "./components/App";

document.getElementById("app")!.innerHTML = renderApp();

import { initNavigation } from "./components/Navigation";
import { initBanner } from "./components/Banner";

initNavigation();
initBanner();
