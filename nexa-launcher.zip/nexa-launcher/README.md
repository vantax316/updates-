# Nexa Launcher

Built with **Tauri + TypeScript + Vite**.

## Setup

### 1. Prerequisites
- Node.js 18+
- Rust (stable) — https://rustup.rs
- Windows: Microsoft C++ Build Tools + WebView2

### 2. Add your banner image
Save your action-scene image (the train fight screenshot) as:
```
src/assets/banner.jpg
```
It will show in both the hero banner AND the season card thumbnail automatically.

### 3. Run
```bash
npm install
npm run tauri dev
```

### 4. Build release
```bash
npm run tauri build
```

## Structure
```
nexa-launcher/
├── src/
│   ├── assets/banner.jpg        ← YOUR IMAGE GOES HERE
│   ├── components/
│   │   ├── App.ts               ← HTML layout
│   │   ├── Navigation.ts        ← Tab switching + window controls
│   │   └── Banner.ts            ← Play button + card parallax
│   ├── main.ts
│   └── style.css
├── src-tauri/
│   ├── icons/                   ← Already generated, no action needed
│   ├── src/main.rs
│   ├── Cargo.toml
│   ├── build.rs
│   └── tauri.conf.json
├── index.html
├── package.json
└── vite.config.ts
```
